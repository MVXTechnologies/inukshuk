<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:app="https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" gml:id="idf9975e80-3fad-4cb5-8aaf-6b2ae08af2c7" xsi:schemaLocation="https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801 https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801/fastmerker.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
			<gml:lowerCorner>58.006427 4.632972</gml:lowerCorner>
			<gml:upperCorner>78.943906 31.103385</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<gml:featureMember>
		<app:Fastmerke gml:id="id778b362a-8850-4472-8737-27b988369439">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>f70c1cec-d0d3-48f5-b0e4-8b67d54c9c96</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_hoydefastmerke</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>2008-02-12T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>55</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>100000</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>100000</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id778b362a-8850-4472-8737-27b988369439-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>59.938902 11.062274</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>G35AN049</app:punktNummer>
			<app:fastmerkeNavn>Skjønhaug</app:fastmerkeNavn>
			<app:punkttype>nivPunkt</app:punkttype>
			<app:fastmerkestatus>
				<app:Fastmerkestatus>
					<app:verifiseringsdato>1956-12-31T00:00:00</app:verifiseringsdato>
					<app:typeStatus>funnetIOrden</app:typeStatus>
				</app:Fastmerkestatus>
			</app:fastmerkestatus>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>3224</app:kommune>
			<app:punktBeskrivelse>I fjell, ca 2,5 m fra og 0,5 m over veibanen.  1 m fra gjerde.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>6646402</app:nordKoordinat>
			<app:østKoordinat>615228.5</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6651152</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>280044</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>215922</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>19241</app:østKoordinatNGO1948>
			<app:høydeNN1954>133.669</app:høydeNN1954>
			<app:høydeNormalNN2000>133.848</app:høydeNormalNN2000>
			<app:beregningsDatoNN1954>1956-12-31</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id536a4c71-67b7-4ac5-aeea-109830a8217b">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>0ae5b4a1-6ee3-4738-9c87-7e49c8c37b2d</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_hoydefastmerke</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>2008-02-12T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>55</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>100000</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>100000</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id536a4c71-67b7-4ac5-aeea-109830a8217b-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>59.930350 11.069259</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>G35AN051</app:punktNummer>
			<app:fastmerkeNavn>Hauger</app:fastmerkeNavn>
			<app:punkttype>nivPunkt</app:punkttype>
			<app:fastmerkestatus>
				<app:Fastmerkestatus>
					<app:verifiseringsdato>1956-12-31T00:00:00</app:verifiseringsdato>
					<app:typeStatus>funnetIOrden</app:typeStatus>
				</app:Fastmerkestatus>
			</app:fastmerkestatus>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>3224</app:kommune>
			<app:punktBeskrivelse>I fjellnabbe midt i liten kurve.  Ca 3 m fra og 2 m over veibanen.  Fylling med rekkverk på utsiden.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>6645462</app:nordKoordinat>
			<app:østKoordinat>615648.5</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6650178</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>280378</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>214971</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>19636</app:østKoordinatNGO1948>
			<app:høydeNN1954>171.682</app:høydeNN1954>
			<app:høydeNormalNN2000>171.861</app:høydeNormalNN2000>
			<app:beregningsDatoNN1954>1956-12-31</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id51789f70-1eec-496e-948b-b40ceb322e32">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>81266127-d485-4401-8059-f9a9d3480179</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_hoydefastmerke</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>1999-01-05T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>55</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>100000</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>100000</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id51789f70-1eec-496e-948b-b40ceb322e32-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>59.952470 11.044671</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>G35AN044</app:punktNummer>
			<app:fastmerkeNavn>Skedsmo kommune</app:fastmerkeNavn>
			<app:punkttype>nivPunkt</app:punkttype>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>3205</app:kommune>
			<app:punktBeskrivelse>Polygonpunkt nr 18</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>6647882</app:nordKoordinat>
			<app:østKoordinat>614198.5</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6652720</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>279152</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>217429</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>18249</app:østKoordinatNGO1948>
			<app:høydeNN1954>106.603</app:høydeNN1954>
			<app:høydeNormalNN2000>106.783</app:høydeNormalNN2000>
			<app:beregningsDatoNN1954>1956-12-31</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="idaa043b83-7713-43c0-ab51-a0478ce412f9">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>2d97e8a4-a092-40a2-9c91-a4e20095be90</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_hoydefastmerke</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>1999-01-05T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>55</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>100000</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>100000</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="idaa043b83-7713-43c0-ab51-a0478ce412f9-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>59.952045 11.037303</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>G35AN045</app:punktNummer>
			<app:fastmerkeNavn>Nybrua</app:fastmerkeNavn>
			<app:punkttype>nivPunkt</app:punkttype>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>3224</app:kommune>
			<app:punktBeskrivelse>I fjell, ca 27 m fra brukar for ny bru og ca 1 m over veibanen</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>6647822</app:nordKoordinat>
			<app:østKoordinat>613788.5</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6652698</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>278738</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>217380</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>17838</app:østKoordinatNGO1948>
			<app:høydeNN1954>110.12</app:høydeNN1954>
			<app:høydeNormalNN2000>110.299</app:høydeNormalNN2000>
			<app:beregningsDatoNN1954>1956-12-31</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id2f3505f4-c66b-45c8-bcad-609a1c63763a">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>cd46fc64-128c-45e6-846c-28eac231ef1c</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_hoydefastmerke</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>1999-01-05T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>55</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>100000</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>100000</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id2f3505f4-c66b-45c8-bcad-609a1c63763a-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>59.947344 11.045072</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>G35AN046</app:punktNummer>
			<app:fastmerkeNavn>Rustberget</app:fastmerkeNavn>
			<app:punkttype>nivPunkt</app:punkttype>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>3224</app:kommune>
			<app:punktBeskrivelse>I fjell,  ca 11 m fra og i høyde med veibanen.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>6647312</app:nordKoordinat>
			<app:østKoordinat>614238.5</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6652149</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>279140</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>216858</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>18274</app:østKoordinatNGO1948>
			<app:høydeNN1954>113.938</app:høydeNN1954>
			<app:høydeNormalNN2000>114.118</app:høydeNormalNN2000>
			<app:beregningsDatoNN1954>1956-12-31</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id063f5802-9d60-4923-a7ed-59fda558603f">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>96031b0e-79a0-4845-9a1c-150597972f8f</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_hoydefastmerke</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>1999-01-05T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>55</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>100000</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>100000</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id063f5802-9d60-4923-a7ed-59fda558603f-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>59.943629 11.052900</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>G35AN047</app:punktNummer>
			<app:fastmerkeNavn>Høyenhall</app:fastmerkeNavn>
			<app:punkttype>nivPunkt</app:punkttype>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>3224</app:kommune>
			<app:punktBeskrivelse>I fjell,  ca 5 m fra og 1,5 m over veibanen.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>6646912</app:nordKoordinat>
			<app:østKoordinat>614688.5</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6651710</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>279552</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>216446</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>18714</app:østKoordinatNGO1948>
			<app:høydeNN1954>126.758</app:høydeNN1954>
			<app:høydeNormalNN2000>126.937</app:høydeNormalNN2000>
			<app:beregningsDatoNN1954>1956-12-31</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
</gml:FeatureCollection>
