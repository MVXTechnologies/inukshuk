<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:app="https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" gml:id="id915d2ffd-942b-4593-ba8e-b71628f6812d" xsi:schemaLocation="https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801 https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801/fastmerker.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
			<gml:lowerCorner>57.960320 4.501796</gml:lowerCorner>
			<gml:upperCorner>71.174776 31.168947</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<gml:featureMember>
		<app:Fastmerke gml:id="id811964d9-64ee-42d1-964f-13bbc4ea2e46">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>8e46b7eb-d949-4015-83b4-19956e30321a</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_trekantpunkter</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>2022-02-21T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>93</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>150</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>16</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id811964d9-64ee-42d1-964f-13bbc4ea2e46-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>64.548183 12.155037</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>H21N0088</app:punktNummer>
			<app:fastmerkeNavn>SKILLEBERGET</app:fastmerkeNavn>
			<app:punkttype>trigPunkt</app:punkttype>
			<app:fastmerkestatus>
				<app:Fastmerkestatus>
					<app:verifiseringsdato>1983-12-31T00:00:00</app:verifiseringsdato>
					<app:typeStatus>funnetIOrden</app:typeStatus>
				</app:Fastmerkestatus>
			</app:fastmerkestatus>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>5047</app:kommune>
			<app:punktBeskrivelse>I FAST FJELL, 10 M TIL HØYRE FOR VEGMIDT OG 0.2 M OVER VEGBANEN.</app:punktBeskrivelse>
			<app:sone>33</app:sone>
			<app:naturligAkse>4</app:naturligAkse>
			<app:nordKoordinat>7161160.323</app:nordKoordinat>
			<app:østKoordinat>363614.622</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>7161160.323</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>363614.622</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>729993.222</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>-50951.165</app:østKoordinatNGO1948>
			<app:høydeNN1954>13.654</app:høydeNN1954>
			<app:høydeEllipsoidisk>50.287</app:høydeEllipsoidisk>
			<app:høydeNormalNN2000>13.792</app:høydeNormalNN2000>
			<app:beregningsDatoEuref89>2018-12-05</app:beregningsDatoEuref89>
			<app:beregningsDatoNN1954>2003-02-11</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id6a895064-b14a-49f6-a00e-487e425d7af5">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>beffc540-3a61-4c39-b672-64fc3fb3201b</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_trekantpunkter</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>2022-02-21T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>93</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>150</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>7</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id6a895064-b14a-49f6-a00e-487e425d7af5-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>64.385363 13.631370</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>J21N0048</app:punktNummer>
			<app:fastmerkeNavn>LAUVSJØLIA</app:fastmerkeNavn>
			<app:punkttype>trigPunkt</app:punkttype>
			<app:fastmerkeEtableringsdato>2004</app:fastmerkeEtableringsdato>
			<app:fastmerkestatus>
				<app:Fastmerkestatus>
					<app:verifiseringsdato>1992-12-31T00:00:00</app:verifiseringsdato>
					<app:typeStatus>funnetIOrden</app:typeStatus>
				</app:Fastmerkestatus>
			</app:fastmerkestatus>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>5042</app:kommune>
			<app:punktBeskrivelse>PÅ ØSTRE SIDE AV VEGEN-8,4 M FRA MIDTLINJEN OG CA. 1 M OVER</app:punktBeskrivelse>
			<app:sone>33</app:sone>
			<app:naturligAkse>4</app:naturligAkse>
			<app:nordKoordinat>7140668.428</app:nordKoordinat>
			<app:østKoordinat>433984.742</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>7140668.428</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>433984.742</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>711474.608</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>19984.554</app:østKoordinatNGO1948>
			<app:høydeNN1954>584.725</app:høydeNN1954>
			<app:høydeEllipsoidisk>618.381</app:høydeEllipsoidisk>
			<app:høydeNormalNN2000>584.89</app:høydeNormalNN2000>
			<app:beregningsDatoEuref89>2018-12-05</app:beregningsDatoEuref89>
			<app:beregningsDatoNN1954>2004-12-13</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id9cecd4e8-7939-4922-b207-69dcc6c1be9f">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>7af7e256-df6e-4478-a424-5b4ec3f57629</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_trekantpunkter</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>1999-11-18T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>12</app:målemetode>
					<app:målemetodeHøyde>13</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>30</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>30</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>50</app:nøyaktighetHøydeNN1954>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id9cecd4e8-7939-4922-b207-69dcc6c1be9f-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>58.624318 6.684779</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>C39T0081</app:punktNummer>
			<app:fastmerkeNavn>HISKNUTEN</app:fastmerkeNavn>
			<app:punkttype>trigPunkt</app:punkttype>
			<app:fastmerkeEtableringsdato>1966</app:fastmerkeEtableringsdato>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:boltHøgde>0.05</app:boltHøgde>
			<app:kommune>4228</app:kommune>
			<app:punktBeskrivelse>PÅ NORDPYNTEN AV DEN JEVNHØYE KNUTEN.  1 1/2 TIME KRONGLET MARSJ FRA SIRDALSVATN.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>1</app:naturligAkse>
			<app:nordKoordinat>6500540.47</app:nordKoordinat>
			<app:østKoordinat>365555.924</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6528172.269</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>17857.988</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>69616.362</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>36767.678</app:østKoordinatNGO1948>
			<app:høydeNN1954>487.18</app:høydeNN1954>
			<app:høydeEllipsoidisk>531.361</app:høydeEllipsoidisk>
			<app:beregningsDatoNGO1948>1995-12-31</app:beregningsDatoNGO1948>
			<app:beregningsDatoEuref89>1999-11-18</app:beregningsDatoEuref89>
			<app:beregningsDatoNN1954>1999-11-18</app:beregningsDatoNN1954>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id9ccf6deb-2b63-44a7-bfc9-e8fbfb6fd3de">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>4fa1f50e-467f-4f06-b457-492c73dd1766</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_trekantpunkter</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>1999-11-18T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>12</app:målemetode>
					<app:nøyaktighetNGO1948>30</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>30</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>50</app:nøyaktighetHøydeNN1954>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id9ccf6deb-2b63-44a7-bfc9-e8fbfb6fd3de-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>58.630711 6.782642</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>C39T0082</app:punktNummer>
			<app:fastmerkeNavn>KROSSTJØNNHEI</app:fastmerkeNavn>
			<app:punkttype>trigPunkt</app:punkttype>
			<app:fastmerkeEtableringsdato>1959</app:fastmerkeEtableringsdato>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:boltHøgde>0.08</app:boltHøgde>
			<app:kommune>4228</app:kommune>
			<app:punktBeskrivelse>PÅ HØYESTE TOPP AV KROSSFONNHEIA.  1 TIME FRA OVEDAL. GOD VEI OPP TIL HEIS FRA OVEDAL.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>1</app:naturligAkse>
			<app:nordKoordinat>6501060.01</app:nordKoordinat>
			<app:østKoordinat>371260.966</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6528179.038</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>23601.557</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>70385.866</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>42445.645</app:østKoordinatNGO1948>
			<app:høydeNN1954>605.618</app:høydeNN1954>
			<app:høydeEllipsoidisk>649.843</app:høydeEllipsoidisk>
			<app:beregningsDatoNGO1948>1995-12-31</app:beregningsDatoNGO1948>
			<app:beregningsDatoEuref89>1999-11-18</app:beregningsDatoEuref89>
			<app:beregningsDatoNN1954>1995-12-31</app:beregningsDatoNN1954>
		</app:Fastmerke>
	</gml:featureMember>
</gml:FeatureCollection>
