<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:app="https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" gml:id="ide2597274-1008-4c75-a3bd-03102ad60b9a" xsi:schemaLocation="https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801 https://skjema.geonorge.no/SOSI/produktspesifikasjon/Fastmerker/20230801/fastmerker.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
			<gml:lowerCorner>57.961922 4.513157</gml:lowerCorner>
			<gml:upperCorner>78.943299 31.116654</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<gml:featureMember>
		<app:Fastmerke gml:id="id0c27b116-c46d-4803-b97d-6d2329f7872d">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>972ade44-d0ae-4619-835a-8b9d5cfa5f02</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_landsnett_stamnett</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>2022-02-21T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>93</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>30</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>6</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>5</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>41</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id0c27b116-c46d-4803-b97d-6d2329f7872d-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>63.491077 11.261331</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>H24T0200</app:punktNummer>
			<app:fastmerkeNavn>TYLDA</app:fastmerkeNavn>
			<app:punkttype>landsnettPunkt</app:punkttype>
			<app:fastmerkestatus>
				<app:Fastmerkestatus>
					<app:verifiseringsdato>2012-12-31T00:00:00</app:verifiseringsdato>
				</app:Fastmerkestatus>
			</app:fastmerkestatus>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:boltHøgde>0.03</app:boltHøgde>
			<app:kommune>5035</app:kommune>
			<app:punktBeskrivelse>F-K BOLT I FJELL  CA 5 M FRA GÅRDSVEGEN.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>7042294.25</app:nordKoordinat>
			<app:østKoordinat>612596.297</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>7045741.755</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>313894.501</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>611842.279</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>27088.356</app:østKoordinatNGO1948>
			<app:høydeNN1954>58.44</app:høydeNN1954>
			<app:høydeEllipsoidisk>96.699</app:høydeEllipsoidisk>
			<app:høydeNormalNN2000>58.614</app:høydeNormalNN2000>
			<app:beregningsDatoEuref89>2018-12-05</app:beregningsDatoEuref89>
			<app:beregningsDatoNN1954>1997-12-02</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2013-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id23a1275e-2561-4661-9ef5-94c2baff9c8d">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>8f729708-3df4-4fb7-bee9-7c831e7fc226</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_landsnett_stamnett</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>2022-02-21T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>93</app:målemetode>
					<app:målemetodeHøyde>15</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>150</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>7</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>1</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>2</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id23a1275e-2561-4661-9ef5-94c2baff9c8d-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>63.003916 11.683415</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>H25N0016</app:punktNummer>
			<app:fastmerkeNavn>HÅVELSENGET</app:fastmerkeNavn>
			<app:punkttype>landsnettPunkt</app:punkttype>
			<app:fastmerkeEtableringsdato>1998</app:fastmerkeEtableringsdato>
			<app:fastmerkestatus>
				<app:Fastmerkestatus>
					<app:verifiseringsdato>1990-12-31T00:00:00</app:verifiseringsdato>
					<app:typeStatus>funnetIOrden</app:typeStatus>
				</app:Fastmerkestatus>
			</app:fastmerkestatus>
			<app:fastmerkeUnderlag>fjell</app:fastmerkeUnderlag>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:kommune>5033</app:kommune>
			<app:punktBeskrivelse>PÅ LITEN FLAT BERGNABBE 25 M ØST FOR RIKSVEG 705. 8 M VEST LYSSTOLPE.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>3</app:naturligAkse>
			<app:nordKoordinat>6988861.411</app:nordKoordinat>
			<app:østKoordinat>635874.42</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6990357.666</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>332084.165</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>557791.891</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>48928.726</app:østKoordinatNGO1948>
			<app:høydeNN1954>537.89</app:høydeNN1954>
			<app:høydeEllipsoidisk>576.032</app:høydeEllipsoidisk>
			<app:høydeNormalNN2000>538.1</app:høydeNormalNN2000>
			<app:beregningsDatoEuref89>2018-12-05</app:beregningsDatoEuref89>
			<app:beregningsDatoNN1954>2003-10-15</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2008-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
<gml:featureMember>
		<app:Fastmerke gml:id="id4c3dd9cb-d717-43e8-b2fc-2314f7127af7">
			<app:identifikasjon>
				<app:Identifikasjon>
					<app:lokalId>bad1af0d-cc02-4bd7-96fe-701f50885eff</app:lokalId>
					<app:navnerom>https://data.geonorge.no/sosi/hoydedata/fastmerker_landsnett_stamnett</app:navnerom>
				</app:Identifikasjon>
			</app:identifikasjon>
			<app:oppdateringsdato>2022-02-18T00:00:00</app:oppdateringsdato>
			<app:kvalitet>
				<app:Posisjonskvalitet>
					<app:målemetode>93</app:målemetode>
					<app:målemetodeHøyde>93</app:målemetodeHøyde>
					<app:nøyaktighetNGO1948>30</app:nøyaktighetNGO1948>
					<app:nøyaktighetEUREF89>7</app:nøyaktighetEUREF89>
					<app:nøyaktighetHøydeNN1954>30</app:nøyaktighetHøydeNN1954>
					<app:nøyaktighetHøydeNN2000>40</app:nøyaktighetHøydeNN2000>
				</app:Posisjonskvalitet>
			</app:kvalitet>
			<app:posisjon>
				<gml:Point gml:id="id4c3dd9cb-d717-43e8-b2fc-2314f7127af7-0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
					<gml:pos>58.645244 6.981365</gml:pos>
				</gml:Point>
			</app:posisjon>
			<app:punktNummer>C39T0080</app:punktNummer>
			<app:fastmerkeNavn>HEIEFJELL</app:fastmerkeNavn>
			<app:punkttype>landsnettPunkt</app:punkttype>
			<app:fastmerkeEtableringsdato>1959</app:fastmerkeEtableringsdato>
			<app:fastmerkeSentrumRef>toppBolt</app:fastmerkeSentrumRef>
			<app:fastmerkeHøydeRef>toppBolt</app:fastmerkeHøydeRef>
			<app:boltHøgde>0.075</app:boltHøgde>
			<app:kommune>4227</app:kommune>
			<app:punktBeskrivelse>PÅ HØYESTE TOPP MOT KNABEN GÅRD.  1 1/2 TIME FRA KNABEN GÅRD. 3/4 TIME FRA HÅLAND GÅRD.</app:punktBeskrivelse>
			<app:sone>32</app:sone>
			<app:naturligAkse>1</app:naturligAkse>
			<app:nordKoordinat>6502313.486</app:nordKoordinat>
			<app:østKoordinat>382845.164</app:østKoordinat>
			<app:nordKoordinatEuref89Sone33>6528391.043</app:nordKoordinatEuref89Sone33>
			<app:østKoordinatEuref89Sone33>35280.936</app:østKoordinatEuref89Sone33>
			<app:nordKoordinatNGO1948>72146.862</app:nordKoordinatNGO1948>
			<app:østKoordinatNGO1948>53966.56</app:østKoordinatNGO1948>
			<app:høydeNN1954>815.148</app:høydeNN1954>
			<app:høydeEllipsoidisk>859.347</app:høydeEllipsoidisk>
			<app:høydeNormalNN2000>815.036</app:høydeNormalNN2000>
			<app:beregningsDatoNGO1948>1995-12-31</app:beregningsDatoNGO1948>
			<app:beregningsDatoEuref89>2018-12-04</app:beregningsDatoEuref89>
			<app:beregningsDatoNN1954>1999-11-18</app:beregningsDatoNN1954>
			<app:beregningsDatoNN2000>2015-12-31</app:beregningsDatoNN2000>
		</app:Fastmerke>
	</gml:featureMember>
</gml:FeatureCollection>
